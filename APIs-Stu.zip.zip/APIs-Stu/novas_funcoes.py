def nova_funcao():
    print("Nova funçao")