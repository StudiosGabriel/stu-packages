from .novas_funcoes import nova_funcao
