def nova_funcao():
    print("Nova função do pacote APIs-Stu funcionando!")
